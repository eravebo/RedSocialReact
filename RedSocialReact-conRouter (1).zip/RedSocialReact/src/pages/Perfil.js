import React from 'react';

function Perfil() {
  return (
    <div className="w3-container w3-content" style={{ maxWidth: '1400px', marginTop: '80px' }}>
      <div className="w3-card w3-round w3-white w3-padding">
        <h2><i className="fa fa-user w3-margin-right"></i>Mi Perfil</h2>
        <hr />
        <p>Aquí se mostrará la información completa del perfil del usuario.</p>
      </div>
    </div>
  );
}

export default Perfil;
