import React from 'react';

function Mensajes() {
  return (
    <div className="w3-container w3-content" style={{ maxWidth: '1400px', marginTop: '80px' }}>
      <div className="w3-card w3-round w3-white w3-padding">
        <h2><i className="fa fa-envelope w3-margin-right"></i>Mensajes</h2>
        <hr />
        <p>Aquí aparecerán tus conversaciones privadas.</p>
      </div>
    </div>
  );
}

export default Mensajes;
