import React from 'react';

function Noticias() {
  return (
    <div className="w3-container w3-content" style={{ maxWidth: '1400px', marginTop: '80px' }}>
      <div className="w3-card w3-round w3-white w3-padding">
        <h2><i className="fa fa-globe w3-margin-right"></i>Noticias</h2>
        <hr />
        <p>Aquí aparecerán las últimas noticias de tu red.</p>
      </div>
    </div>
  );
}

export default Noticias;
