import React from 'react';

function Footer() {
  return (
    <>
      <footer className="w3-container w3-theme-d3 w3-padding-16">
        <h5>Footer</h5>
      </footer>
      <footer className="w3-container w3-theme-d5">
        <p>
          Powered by{' '}
          <a href="https://www.w3schools.com/w3css/default.asp" target="_blank" rel="noreferrer">
            w3.css
          </a>
        </p>
      </footer>
    </>
  );
}

export default Footer;
