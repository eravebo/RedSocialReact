import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  const [menuAbierto, setMenuAbierto] = useState(false);

  const toggleMenu = () => {
    setMenuAbierto(!menuAbierto);
  };

  return (
    <>
      {/* Navbar principal */}
      <div className="w3-top">
        <div className="w3-bar w3-theme-d2 w3-left-align w3-large">

          {/* Botón hamburguesa para móvil */}
          <button
            className="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2"
            onClick={toggleMenu}
          >
            <i className="fa fa-bars"></i>
          </button>

          {/* Logo */}
          <Link to="/" className="w3-bar-item w3-button w3-padding-large w3-theme-d4">
            <i className="fa fa-home w3-margin-right"></i>Logo
          </Link>

          {/* Íconos de navegación */}
          <Link to="/noticias" className="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Noticias">
            <i className="fa fa-globe"></i>
          </Link>
          <Link to="/perfil" className="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Configuración de cuenta">
            <i className="fa fa-user"></i>
          </Link>
          <Link to="/mensajes" className="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Mensajes">
            <i className="fa fa-envelope"></i>
          </Link>

          {/* Dropdown Notificaciones */}
          <div className="w3-dropdown-hover w3-hide-small">
            <button className="w3-button w3-padding-large" title="Notificaciones">
              <i className="fa fa-bell"></i>
              <span className="w3-badge w3-right w3-small w3-green">3</span>
            </button>
            <div className="w3-dropdown-content w3-card-4 w3-bar-block" style={{ width: '300px' }}>
              <a href="#" className="w3-bar-item w3-button">Nueva solicitud de amistad</a>
              <a href="#" className="w3-bar-item w3-button">John Doe publicó en tu muro</a>
              <a href="#" className="w3-bar-item w3-button">Jane le gusta tu publicación</a>
            </div>
          </div>

          {/* Avatar usuario */}
          <Link to="/perfil" className="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="Mi Cuenta">
            <img
              src="https://www.w3schools.com//w3images/avatar2.png"
              className="w3-circle"
              style={{ height: '23px', width: '23px' }}
              alt="Avatar"
            />
          </Link>

        </div>
      </div>

      {/* Navbar para pantallas pequeñas */}
      <div
        id="navDemo"
        className={`w3-bar-block w3-theme-d2 w3-hide-large w3-hide-medium w3-large ${menuAbierto ? 'w3-show' : 'w3-hide'}`}
      >
        <Link to="/"         className="w3-bar-item w3-button w3-padding-large">Inicio</Link>
        <Link to="/noticias" className="w3-bar-item w3-button w3-padding-large">Noticias</Link>
        <Link to="/mensajes" className="w3-bar-item w3-button w3-padding-large">Mensajes</Link>
        <Link to="/perfil"   className="w3-bar-item w3-button w3-padding-large">Mi Perfil</Link>
      </div>
    </>
  );
}

export default Navbar;
