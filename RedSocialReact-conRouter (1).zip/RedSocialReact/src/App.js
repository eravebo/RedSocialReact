import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Inicio from './pages/Inicio';
import Noticias from './pages/Noticias';
import Perfil from './pages/Perfil';
import Mensajes from './pages/Mensajes';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/"         element={<Inicio />} />
        <Route path="/noticias" element={<Noticias />} />
        <Route path="/perfil"   element={<Perfil />} />
        <Route path="/mensajes" element={<Mensajes />} />
      </Routes>

      <br />
      <Footer />
    </BrowserRouter>
  );
}

export default App;
